﻿using FinalProject.Models;

namespace E_Commerce.Interfaces
{
    public interface ICategoryRepository
    {
        Task<IEnumerable<Category>> GetAllAsync();
        Task<Category> GetByIdAsync(int id);
        Task AddAsync(Category category);
        Task UpdateAsync(Category category);
        Task DeleteAsync(Category category);
        Task<bool> ExistsAsync(int id);
        Task<bool> IsNameExists(string name);
        IQueryable<Category> GetQueryable();
    }
}
