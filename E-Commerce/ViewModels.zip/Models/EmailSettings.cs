﻿namespace E_Commerce.Models
{
    public class EmailSettings
    {
        public string smtpServer { get; set; } 
        public int Port { get; set; }
        public string SenderName { get; set; }
        public string SenderEmail { get; set; }
        public string SenderPassword { get; set; }
    }
}
