﻿using System.ComponentModel.DataAnnotations;

namespace E_Commerce.ViewModels.Account
{
    public class LoginUserVM
    {
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        public bool RememberMe { get; set; }  
    }
}
